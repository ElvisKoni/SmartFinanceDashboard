# SmartFinance Dashboard

A simple financial analysis and visualization web app.