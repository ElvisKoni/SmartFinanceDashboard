# Entry point for the SmartFinance Dashboard app
